package main.java.djcontroller;

public class MainLauncher {
    public static void main(String[] args) {
        Main.main(args);
    }
}
